import React from 'react'
import { createAppContainer } from 'react-navigation'
import AppDrawerNavigator from './drawer';

export default createAppContainer(AppDrawerNavigator)
